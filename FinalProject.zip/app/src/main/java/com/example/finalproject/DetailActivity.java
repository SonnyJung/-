package com.example.finalproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class DetailActivity extends AppCompatActivity {
    private RecyclerView detailRecyclerView;
    private RecyclerView.LayoutManager detailLayoutManager;
    private TextView maker;
    private TextView makerUrl;
    private TextView item;
    private TextView price;
    private TextView explanation;
    private CheckBox cb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ViewCompat.setTranslationZ(toolbar, 1);


        detailRecyclerView = (RecyclerView) findViewById(R.id.recyclerView2);
        detailRecyclerView.setHasFixedSize(true);
        detailLayoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        detailRecyclerView.setLayoutManager(detailLayoutManager);

        Intent intent = getIntent();

        ArrayList<Integer> imageIDs = new ArrayList<>();
        imageIDs.add(intent.getIntExtra("imageID1",0));
        imageIDs.add(intent.getIntExtra("imageID2",0));
        imageIDs.add(intent.getIntExtra("imageID3",0));

        DetailAdapter detailAdapter = new DetailAdapter(imageIDs);

        detailRecyclerView.setAdapter(detailAdapter);

        maker = (TextView) findViewById(R.id.textView2);
        makerUrl = (TextView)findViewById(R.id.textView3);
        item = (TextView) findViewById(R.id.textView7);
        price = (TextView) findViewById(R.id.textView8);
        explanation = (TextView)findViewById(R.id.textView9);



        maker.setText(intent.getStringExtra("itemMaker"));
        item.setText(intent.getStringExtra("itemName"));
        price.setText(intent.getStringExtra("itemPrice")+"원");
        makerUrl.setText(intent.getStringExtra("itemMakerURL"));
        explanation.setText("사이즈 정보: 230mm ~ 290mm(5mm 단위)\n\n"+maker.getText()+"의 스테디셀러 "+item.getText()+"입니다.\n"+item.getText()+"를 경험해보세요.\n");

        makerUrl.setOnClickListener(new View.OnClickListener(){
           public void onClick(View v){
               Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse((String) makerUrl.getText()));
               startActivity(intent);
           }
        });
        cb = (CheckBox)findViewById(R.id.checkBox);
        cb.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                if(cb.isChecked()){
                    ContentValues addValues = new ContentValues();
                    addValues.put(MyContentProvider.IMG_ID, imageIDs.get(0).toString());
                    addValues.put(MyContentProvider.NAME, item.getText().toString());
                    addValues.put(MyContentProvider.PRICE, price.getText().toString());
                    addValues.put(MyContentProvider.MAKER, maker.getText().toString());


                    getContentResolver().insert(MyContentProvider.CONTENT_URI, addValues);
                    Toast.makeText(getBaseContext(), "장바구니에 담겼습니다.", Toast.LENGTH_LONG).show();
                }
                else{

                    getContentResolver().delete(MyContentProvider.CONTENT_URI,MyContentProvider.IMG_ID + "=" + imageIDs.get(0).toString(),null);
                    Toast.makeText(getBaseContext(), "장바구니에서 삭제했습니다.", Toast.LENGTH_LONG).show();
                }
            }
        });
    }


    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }





}