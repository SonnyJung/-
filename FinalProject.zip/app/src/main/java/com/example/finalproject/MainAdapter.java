package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainAdapter extends RecyclerView.Adapter<MainAdapter.MyViewHolder> {
    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView pic;
        TextView text_maker;
        TextView text_item;

        MyViewHolder(View view){
            super(view);
            pic = view.findViewById(R.id.imageView7);
            text_maker = view.findViewById(R.id.textView3);
            text_item = view.findViewById(R.id.textView4);
        }
    }
    private ArrayList<Items> myItemsList;
    MainAdapter(ArrayList<Items> items){this.myItemsList = items;}

    @Override
    public MainAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent,int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_view,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(MainAdapter.MyViewHolder holder, final int position){
        MyViewHolder myViewHolder = (MyViewHolder) holder;

        myViewHolder.pic.setImageResource(myItemsList.get(position).getImage_id_1());
        myViewHolder.text_maker.setText(myItemsList.get(position).getItem_maker());
        myViewHolder.text_item.setText(myItemsList.get(position).getItemName());

        myViewHolder.pic.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Context context = v.getContext();
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("imageID1",myItemsList.get(position).getImage_id_1());
                intent.putExtra("imageID2",myItemsList.get(position).getImage_id_2());
                intent.putExtra("imageID3",myItemsList.get(position).getImage_id_3());
                intent.putExtra("itemName",myItemsList.get(position).getItemName());
                intent.putExtra("itemMaker",myItemsList.get(position).getItem_maker());
                intent.putExtra("itemPrice",myItemsList.get(position).getItem_price());
                intent.putExtra("itemMakerURL",myItemsList.get(position).getItem_maker_url());

                context.startActivity(intent);
            }
        });
        myViewHolder.text_item.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Context context = v.getContext();
                Intent intent = new Intent(context, DetailActivity.class);
                intent.putExtra("imageID1",myItemsList.get(position).getImage_id_1());
                intent.putExtra("imageID2",myItemsList.get(position).getImage_id_2());
                intent.putExtra("imageID3",myItemsList.get(position).getImage_id_3());
                intent.putExtra("itemName",myItemsList.get(position).getItemName());
                intent.putExtra("itemMaker",myItemsList.get(position).getItem_maker());
                intent.putExtra("itemPrice",myItemsList.get(position).getItem_price());
                intent.putExtra("itemMakerURL",myItemsList.get(position).getItem_maker_url());

                context.startActivity(intent);
            }
        });
    }
    @Override
    public int getItemCount() {
        return myItemsList.size();
    }
}
