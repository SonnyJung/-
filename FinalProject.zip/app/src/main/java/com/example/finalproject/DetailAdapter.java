package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class DetailAdapter extends RecyclerView.Adapter<DetailAdapter.MyViewHolder2>{
    public class MyViewHolder2 extends RecyclerView.ViewHolder {
        ImageView img1;
        ImageView img2;
        ImageView img3;


        MyViewHolder2(View view) {
            super(view);
            img1 = view.findViewById(R.id.imageView);
            img2 = view.findViewById(R.id.imageView2);
            img3 = view.findViewById(R.id.imageView3);
        }
    }
    private ArrayList<Integer> imagesIDs;
    DetailAdapter(ArrayList<Integer> ids){this.imagesIDs = ids;}

    public DetailAdapter.MyViewHolder2 onCreateViewHolder(ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.detail_view,parent,false);
        return new MyViewHolder2(v);
    }
    @Override
    public void onBindViewHolder(DetailAdapter.MyViewHolder2 holder, final int position){
        MyViewHolder2 myViewHolder2 = (MyViewHolder2) holder;

        myViewHolder2.img1.setImageResource(imagesIDs.get(position));
        myViewHolder2.img2.setImageResource(imagesIDs.get(position));
        myViewHolder2.img3.setImageResource(imagesIDs.get(position));


    }
    @Override
    public int getItemCount() {
        return imagesIDs.size();
    }




}
