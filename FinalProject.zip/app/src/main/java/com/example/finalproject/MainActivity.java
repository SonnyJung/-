package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView mainRecyclerView;
    private RecyclerView.LayoutManager mainLayoutManager;
    private TextView csCenter;
    private RecyclerView cartRecyclerView;
    private RecyclerView.LayoutManager cartLayoutManager;
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.tb1_menu,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()) {
            case R.id.action_shoppingCart:
                Intent intent = new Intent(this, ShoppingCart.class);
                startActivity(intent);

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);




        mainRecyclerView = (RecyclerView) findViewById(R.id.recyclerView3);
        mainRecyclerView.setHasFixedSize(true);
        mainLayoutManager = new LinearLayoutManager(this);
        mainRecyclerView.setLayoutManager(mainLayoutManager);

        ArrayList<Items> itemsInfo = new ArrayList<>();
        itemsInfo.add(new Items(R.drawable.adidas_1_1,R.drawable.adidas_1_2,R.drawable.adidas_1_3, "오즈위고","아디다스","129,000","https://m.adidas.co.kr/"));
        itemsInfo.add(new Items(R.drawable.adidas_2_1,R.drawable.adidas_2_2,R.drawable.adidas_2_3, "스탠스미스", "아디다스", "109,000","https://m.adidas.co.kr/"));
        itemsInfo.add(new Items(R.drawable.converse_1_1,R.drawable.converse_1_2,R.drawable.converse_1_3, "척 테일러 올스타 캔버스 리프트", "컨버스","75,000","https://www.converse.co.kr/" ));
        itemsInfo.add(new Items(R.drawable.converse_2_1,R.drawable.converse_2_2,R.drawable.converse_2_3, "런스타하이크","컨버스","75,000","https://www.converse.co.kr/"));
        itemsInfo.add(new Items(R.drawable.covernat_1_1,R.drawable.covernat_1_2,R.drawable.covernat_1_3, "커버네이비","커버낫","79,000","https://www.covernat.net/"));
        itemsInfo.add(new Items(R.drawable.discovery_1_1,R.drawable.discovery_1_2,R.drawable.discovery_1_3, "브릭", "디스커버리 익스페디션","109,000","https://www.discovery-expedition.com/"));
        itemsInfo.add(new Items(R.drawable.fila_1_1,R.drawable.fila_1_2,R.drawable.fila_1_3,"엘리트 코트","휠라","49,000","https://www.fila.co.kr/" ));
        itemsInfo.add(new Items(R.drawable.fila_2_1,R.drawable.fila_2_2,R.drawable.fila_2_3, "룰즈","휠라","69,000","https://www.fila.co.kr/"));
        itemsInfo.add(new Items(R.drawable.lecoq_1_1,R.drawable.lecoq_1_2,R.drawable.lecoq_1_3, "리치알트", "르꼬끄", "129,000", "https://lecoqsportif.co.kr/"));
        itemsInfo.add(new Items(R.drawable.nike_1_1, R.drawable.nike_1_2, R.drawable.nike_1_3, "에어포스 원 크레이터","나이키","139,000","https://www.nike.com"));
        itemsInfo.add(new Items(R.drawable.reebok_1_1,R.drawable.reebok_1_2,R.drawable.reebok_1_3,"로얄브릿지","리복","79,000","https://shop.reebok.co.kr/"));
        itemsInfo.add(new Items(R.drawable.vans_1_1,R.drawable.vans_1_2,R.drawable.vans_1_3, "올드스쿨 블랙","반스","69,000","https://www.vans.co.kr/"));

        MainAdapter mainAdapter = new MainAdapter(itemsInfo);

        mainRecyclerView.setAdapter(mainAdapter);

        csCenter = (TextView) findViewById(R.id.textView6);
        csCenter.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Context context = v.getContext();
                Intent intent = new Intent(context, CSCenterActivity.class);
                startActivity(intent);
            }
        });




    }

}