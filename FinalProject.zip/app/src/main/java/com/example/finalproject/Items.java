package com.example.finalproject;

public class Items {
    int image_id_1;
    int image_id_2;
    int image_id_3;
    String item_name;
    String item_maker;
    String item_price;
    String item_maker_url;

    public Items(int id, String name, String maker, String price){
        this.image_id_1 = id;
        this.item_name = name;
        this.item_price = price;
        this.item_maker = maker;
    }

    public Items(int id1,int id2, int id3, String name, String maker, String price, String url){
        this.image_id_1 = id1;
        this.image_id_2 = id2;
        this.image_id_3 = id3;
        this.item_name = name;
        this.item_price = price;
        this.item_maker = maker;
        this.item_maker_url = url;
    }

    public String getItemName(){return item_name;}
    public String getItem_maker(){return item_maker;}
    public String getItem_price(){return item_price;}
    public String getItem_maker_url(){return item_maker_url;}
    public int getImage_id_1(){return image_id_1;}
    public int getImage_id_2(){return image_id_2;}
    public int getImage_id_3(){return image_id_3;}

}
