package com.example.finalproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.MyViewHolder> {

    public class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView pic;
        TextView text_name;
        TextView text_maker;
        TextView text_price;




        MyViewHolder(View view){
            super(view);
            pic = view.findViewById(R.id.imageView4);
            text_name = view.findViewById(R.id.textView15);
            text_maker = view.findViewById(R.id.textView16);
            text_price = view.findViewById(R.id.textView17);


        }
    }
    private ArrayList<Items> myItemsList;
    CartAdapter(ArrayList<Items> items){this.myItemsList = items;}

    @Override
    public CartAdapter.MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_view,parent,false);

        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(CartAdapter.MyViewHolder holder, final int position){
        MyViewHolder myViewHolder = (MyViewHolder) holder;

        myViewHolder.pic.setImageResource(myItemsList.get(position).getImage_id_1());
        myViewHolder.text_maker.setText(myItemsList.get(position).getItem_maker());
        myViewHolder.text_name.setText(myItemsList.get(position).getItemName());
        myViewHolder.text_price.setText(myItemsList.get(position).getItem_price());


    }
    @Override
    public int getItemCount() {
        return myItemsList.size();
    }
}
