package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.ViewCompat;
import androidx.fragment.app.FragmentActivity;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;


public class CSCenterActivity extends AppCompatActivity {
    private TextView phoneNum;
    private TextView email;
    private TextView location;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cscenter);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar2);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ViewCompat.setTranslationZ(toolbar, 1);

        phoneNum = (TextView) findViewById(R.id.textView14);
        phoneNum.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Context context = v.getContext();
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("tel:"+(String)phoneNum.getText()));
                startActivity(intent);
            }
        });
        email = (TextView) findViewById(R.id.textView12);
        email.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){ sendEmail();}
        });
        location = (TextView) findViewById(R.id.textView10);
        location.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Context context = v.getContext();
                Intent intent = new Intent(context, MapsActivity.class);
                startActivity(intent);
            }
        });



    }

    protected void sendEmail() {
        String[] TO = {"stayend2@naver.com"};
        String[] CC = {""};
        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setData(Uri.parse("mailto:"));
        emailIntent.setType("text/plain");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
        emailIntent.putExtra(Intent.EXTRA_CC, CC);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "고객문의");
        emailIntent.putExtra(Intent.EXTRA_TEXT, "고객센터 문의");
        try {
            startActivity(Intent.createChooser(emailIntent, "이메일 보내기"));
            finish();
        } catch (android.content.ActivityNotFoundException ex)
        {
            Toast.makeText(CSCenterActivity.this, "이메일 클라이언트가 없네요.", Toast.LENGTH_SHORT).show();
        }
    }



    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }



}