package com.example.finalproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBManager extends SQLiteOpenHelper {
    static final String ITEM_DB = "Items.db";
    static final String ITEM_TABLE  = "Items";
    Context context =null;

    private static DBManager dbManager =null;
    static final String CREATE_DB = " CREATE TABLE "+ITEM_TABLE+"(img_id INTEGER PRIMARY KEY AUTOINCREMENT, "+
            "name TEXT NOT NULL, price TEXT NOT NULL, maker TEXT NOT NULL );";

    public static DBManager getInstance(Context context){
        if(dbManager==null){
            dbManager=new DBManager(context,ITEM_DB,null,1);
        }
        return dbManager;
    }

    public DBManager(Context context, String dbName, SQLiteDatabase.CursorFactory factory, int version){
        super(context, dbName,factory,version);
        this.context = context;
    }
    @Override
    public void onOpen(SQLiteDatabase db){
        super.onOpen(db);
    }
    @Override
    public void onCreate(SQLiteDatabase db){
        db.execSQL(CREATE_DB);
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldV, int newV){

    }
    public long insert(ContentValues addValue) {
        return getWritableDatabase().insert(ITEM_TABLE, null, addValue);
    }
    public Cursor query(String [] columns, String selection,
                        String[] selectionArgs, String groupBy, String having,
                        String orderBy){
        return getReadableDatabase().query(ITEM_TABLE, columns, selection, selectionArgs, groupBy, having, orderBy);
    }
    public int delete(String whereClause, String[] whereArgs)
    {
        return getWritableDatabase().delete(ITEM_TABLE, whereClause, whereArgs);
    }
}
