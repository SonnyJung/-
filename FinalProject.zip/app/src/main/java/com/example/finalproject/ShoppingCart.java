package com.example.finalproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ShoppingCart extends AppCompatActivity {
    private TextView text_total;
    private RecyclerView cartRecyclerView;
    private RecyclerView.LayoutManager cartLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_cart);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar3);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        ViewCompat.setTranslationZ(toolbar, 1);


        cartRecyclerView  = (RecyclerView) findViewById(R.id.recyclerView3);
        cartRecyclerView.setHasFixedSize(true);
        cartLayoutManager = new LinearLayoutManager(this);
        cartRecyclerView.setLayoutManager(cartLayoutManager);
        ArrayList cart = new ArrayList();
        String[] columns = new String[]{"img_id", "name", "price","maker"};
        Cursor c = getContentResolver().query(MyContentProvider.CONTENT_URI, columns,
                null, null, null, null);
        if(c!=null){
            while(c.moveToNext()){
                int id = c.getInt(0);
                String name = c.getString(1);
                String price = c.getString(2);
                String maker = c.getString(3);
                cart.add(new Items(id,name,maker,price));
            }
        }
        CartAdapter cartAdapter = new CartAdapter(cart);

        cartRecyclerView.setAdapter(cartAdapter);





    }


    public boolean onOptionsItemSelected(MenuItem item){
        switch(item.getItemId()){
            case android.R.id.home:
                this.finish();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}